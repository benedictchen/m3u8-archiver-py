M3U8 Python Archiver
====================
Given an m3u8 URL, will download ALL variable bitrate m3u8 children and all associated
`.ts` files, any encryption keys.

This is open, MIT licensed.  Please feel free to use.

Usage:
------

```
pip3 install -r requirements.txt 
python3 download.py <M3U8_URL>
```
